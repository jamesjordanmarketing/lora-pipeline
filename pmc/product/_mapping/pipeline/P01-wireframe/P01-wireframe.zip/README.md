
  # P01-QA+5+4+3+2+1 Wireframes — LoRA Training Infrastructure: Dashboard Shell & Global Navigation (Copy)

  This is a code bundle for P01-QA+5+4+3+2+1 Wireframes — LoRA Training Infrastructure: Dashboard Shell & Global Navigation (Copy). The original project is available at https://www.figma.com/design/kIYRG2E1zYERFpWq5gcuaO/P01-QA-5-4-3-2-1-Wireframes-%E2%80%94-LoRA-Training-Infrastructure--Dashboard-Shell---Global-Navigation--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  